# Databricks notebook source
from pyspark.sql import *

# COMMAND ----------

# MAGIC %md
# MAGIC ###Define startdate and end date

# COMMAND ----------

start_date = "2024-01-01"
end_date = "2025-12-01"

# COMMAND ----------

df = (
     spark.sql(f"""
               select explode(
                   sequence(
                       to_date('{start_date}'),
                       to_date('{end_date}'),
                       interval 1 month
                   )
               ) as month_start_date
               """)
)

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import (
    col, date_format, year, concat, lit, quarter
)
df=(
    df
    .withColumn("date-key",date_format(col("month_start_date"),"yyyyMM").cast("int"))
    .withColumn("year",year(col("month_start_date")))
    .withColumn("month_name",date_format(col("month_start_date"),"MMM"))
    .withColumn("quater",concat(lit("Q"),quarter("month_start_date")))
    .withColumn("year_quater",concat(col("year"),lit("-Q"),quarter("month_start_date")))
)

# COMMAND ----------

df.show()

# COMMAND ----------

df.write\
    .mode("overwrite")\
    .saveAsTable("fmcg.gold.dim_date")

# COMMAND ----------

