# Databricks notebook source
from pyspark.sql import functions as F
from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %run /Workspace/Users/kosurusrihari5@gmail.com/consolidation_pipeline/utilits

# COMMAND ----------

dbutils.widgets.text("catalog","fmcg","Catalog")
dbutils.widgets.text("data_source","products","Data Source")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")
data_source = dbutils.widgets.get("data_source")

# COMMAND ----------

base_path = f'{catalog}.{bronze_schema}.{data_source}'
print(base_path)

# COMMAND ----------

from pyspark.sql import functions as F

# catalog = "fmcg"
# bronze_schema = "bronze"
# data_source = "products"

base_path = f"{catalog}.{bronze_schema}.{data_source}"

df_bronze = spark.table(base_path)

display(df_bronze)
df_bronze.printSchema()

# COMMAND ----------

df_bronze.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .mode("overwrite") \
 .saveAsTable(f"{catalog}.{bronze_schema}.{data_source}")

# COMMAND ----------


spark.catalog.tableExists("fmcg.bronze.products")

# COMMAND ----------

# MAGIC %md
# MAGIC **Transformations**

# COMMAND ----------

#droping duplicate values
print("before droping duplicates",df_bronze.count())
df_silver = df_bronze.dropDuplicates(["product_id"])
print("after droping duplicates",df_silver.count())

# COMMAND ----------

from pyspark.sql.functions import *
df_silver = df_silver.withColumn(
    "category",
    initcap(col("category"))
)
df_silver.show()

# COMMAND ----------

# MAGIC %md
# MAGIC  3   Spelling mistake in protein

# COMMAND ----------

from pyspark.sql.functions import *
# from pyspark.sql.types import regexp_replace
df_silver = (
    df_silver
    .withColumn("product_name",regexp_replace(col("product_name"),"(?i)protien","Protein"))
    .withColumn("category",regexp_replace(col("category"),"(?i)protien","Protein"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Standardizing Customer Attributes to Match Parent Company Data Model
# MAGIC ######### 1: Add division column
# MAGIC

# COMMAND ----------


from pyspark.sql.functions import when
df_silver = (
    df_silver
    .withColumn("division",
                 when(col("category") == "Energy Bars",      "Nutrition Bars")
                .when(col("category")==  "Protein Bars",      "Nutrition Bars")
                .when(col("category") == "Granola & Cereals", "Breakfast Foods")
                .when(col("category") == "Recovery Dairy",     "Dairy & Recovery")
                .when(col("category") == "Healthy Snacks",      "Healthy Snacks")
                .when(col("category")== "Electrolyte Mix",     "Hydration & Electrolytes")
                .otherwise("Other")
                )
)

# COMMAND ----------

display(df_silver.select("division"))

# COMMAND ----------

df_silver = df_silver.withColumn(
    "variant",
    F.regexp_extract(F.col("product_name"), r"\((.*?)\)", 1)
)


# COMMAND ----------

# DBTITLE 1,display the silver data
display(df_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3: Create new column: product_code  
# MAGIC ###### Invalid product_ids are replaced with a fallback value to avoid losing fact records and ensure downstream joins remain consistent
# MAGIC

# COMMAND ----------

df_silver = (
    df_silver
    # 1. Generate deterministic product_code from product_name
    .withColumn(
        "product_code",
        F.sha2(F.col("product_name").cast("string"), 256)
    )
    # 2. Clean product_id: keep only numeric IDs, else set to 999999
    .withColumn(
        "product_id",
        F.when(
            F.col("product_id").cast("string").rlike("^[0-9]+$"),
            F.col("product_id").cast("string")
        ).otherwise(F.lit(999999).cast("string"))
    )
    # 3. Rename product_name → product
    .withColumnRenamed("product_name", "product")
)


# COMMAND ----------

df_silver.printSchema()

# COMMAND ----------

df_silver = df_silver.select(
    "product_code",
    "division",
    "category",
    "product",
    "variant",
    "product_id"
)

display(df_silver)

# COMMAND ----------

df_silver = df_silver.select("product_code", "division", "category", "product", "variant", "product_id")
display(df_silver)

# COMMAND ----------

df_silver.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .option("mergeSchema", "true") \
 .mode("overwrite") \
 .saveAsTable(f"{catalog}.{silver_schema}.{data_source}")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Transforing silver to gold (2_products_data_processing)

# COMMAND ----------

df_silver = spark.sql(f'select * from {catalog}.{silver_schema}.{data_source}')
df_gold  = df_silver.select("product_code","product_id","division","category","product","variant")
df_gold.show(truncate=False)

# COMMAND ----------

# DBTITLE 1,write data to gold layer
# transforming data from silver to gold
df_gold.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed",True)\
    .mode("overwrite")\
    .saveAsTable(f"{catalog}.{gold_schema}.sb_dim_{data_source}")
    

# COMMAND ----------

## Merging Data source with parent
delta_table = DeltaTable.forName(spark, "fmcg.gold.sb_dim_products")
df_child_products = spark.sql(f"SELECT product_code, division, category, product, variant FROM fmcg.gold.sb_dim_products;")
df_child_products.show(5)
delta_table.alias("target").merge(
    source=df_child_products.alias("source"),
    condition="target.product_code = source.product_code"
).whenMatchedUpdate(
    set={
        "division": "source.division",
        "category": "source.category",
        "product": "source.product",
        "variant": "source.variant"
    }
).whenNotMatchedInsert(
    values={
        "product_code": "source.product_code",
        "division": "source.division",
        "category": "source.category",
        "product": "source.product",
        "variant": "source.variant"
    }
).execute()

# COMMAND ----------

