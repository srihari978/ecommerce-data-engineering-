# Databricks notebook source
from pyspark.sql import functions as F
from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %run /Workspace/Users/kosurusrihari5@gmail.com/consolidation_pipeline/utilits

# COMMAND ----------

print(bronze_schema)

# COMMAND ----------

dbutils.widgets.text("catalog","projectatilikon","Catalog")
dbutils.widgets.text("data_source","customers","Data Source")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")
data_source = dbutils.widgets.get("data_source")
# print(catalog,data_source)
base_path = f'{catalog}.{bronze_schema}.{data_source}'
print(base_path)


# COMMAND ----------

df = spark.read.table(base_path)
display(df)

# COMMAND ----------

df.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed", "true")\
    .mode("overwrite")\
    .saveAsTable(f'{catalog}.{bronze_schema}.{data_source}')

# COMMAND ----------

# first schema of the table 
df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC # silver layer customer_data_processing

# COMMAND ----------

df_bronze = spark.sql(f'select * from {catalog}.{bronze_schema}.{data_source}')
df_bronze.printSchema()
df_bronze.show(10)

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ####checking duplicate values in customer_id

# COMMAND ----------

from pyspark.sql.functions import count, col
print(df_bronze.count())
df_duplicates = df_bronze.groupBy("customer_id")\
                         .agg(count("*").alias("count_customer_id"))\
                         .filter(col("count_customer_id") > 1)
df_duplicates.show()
df_duplicates.count()



# COMMAND ----------

df_silver = df_bronze.dropDuplicates(["customer_id"])
df_silver.count()


# COMMAND ----------

from pyspark.sql.functions import trim
df_silver_trim = df_silver.withColumn("customer_name", trim(col("customer_name")))
# display(df_silver_trim)

# COMMAND ----------

print(type(df_silver_trim))
display(df_silver)
display(df_silver_trim)

# COMMAND ----------

df_silver_trim = df_silver.withColumn("customer_name", trim(col("customer_name")))
display(df_silver_trim)

# COMMAND ----------

display(
    df_silver_trim.filter(col("customer_name")!=trim(col("customer_name")))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### distinct city name

# COMMAND ----------

df_silver.select("city").distinct().show()

# COMMAND ----------

#typos -> correct names
from pyspark.sql.functions import when,col
city_mapping = {
    'bengaluruu':'Bengaluru',
    'Bengalore':'Bengaluru',

    'Hyderabadd':'Hyderabad',
    'Hyderbad':'Hyderabad',

    'NewDheli':'New Delhi',
    'NewDelhee':'New Delhi',
    'NewDelhi':'New Delhi'

}

allowed = ["Bengaluru","Hyderabad","New Delhi"]
df_silver = (
    df_silver.replace(city_mapping,subset=["city"])
    .withColumn(
        "city",
        when(col("city").isNull(),None)
        .when(col("city").isin(allowed),col("city"))
        .otherwise(None)
        )
              
)



# COMMAND ----------

df_silver.select("city").distinct().show()

# COMMAND ----------

df_silver.distinct().show()

# COMMAND ----------

# calmel case
from pyspark.sql.functions import initcap
df_silver = df_silver.withColumn(
    "customer_name",
    when(col("customer_name").isNull(),None)
    .otherwise(initcap(col("customer_name")))
)

# COMMAND ----------

df_silver.distinct().show()

# COMMAND ----------

#city with null values
df_silver.filter(col("city").isNull()).show(truncate=False)

# COMMAND ----------

#business confirmation Note:City corrections confiremed by business team
customer_city_fix = {
    # sprintx Nutrition
    789403:"New Delhi",
    #Zenathlete Foods
    789420:"Bengaluru",
    #primeful Nutrition
    789520:"Hyderabad",
    # Recovery Lane
    789603:"Hyderabad"
}

# COMMAND ----------

df_fix = spark.createDataFrame(
    [(k,v) for k,v in customer_city_fix.items()],
    ["customer_id","fixed_city"]
)
display(df_fix)

# COMMAND ----------

from pyspark.sql.functions import coalesce
df_silver = (
    df_silver.join(df_fix,on="customer_id",how="left")
             .withColumn("city",coalesce("city","fixed_city"))
             .drop("fixed_city")
)

# COMMAND ----------

display(df_silver)

# COMMAND ----------

# null_customer_names = ['Sprintx Nutrition', 'Zenathlete Foods', 'Primefuel Nutrition', 'Recovery Lane']
# df_silver.filter(F.col("customer_name").isin(null_customer_names)).show(truncate=False)
#Sanity Check
null_customer_names = ['Sprint Nutrition','Zenathlete Foods','Primefuel Nutrition','Recovery Lane']
df_silver.filter(col("customer_name").isin(null_customer_names)).show(truncate=False)


# COMMAND ----------

df_silver.show()

# COMMAND ----------

df_silver = df_silver.withColumn("customer_id",col("customer_id").cast("string"))
print(df_silver.printSchema())


# COMMAND ----------

from pyspark.sql.functions import *
df_silver = (
    df_silver
    .withColumn(
        "customer",
        concat_ws("-",col("customer_name"),coalesce(col("city"),lit("Unknown")))
    )
    .withColumn("market",lit("India"))
    .withColumn("platform",lit("Sports Bar"))
    .withColumn("channel",lit("Acquisition"))
    )

# COMMAND ----------

df_silver.show(truncate=False)

# COMMAND ----------

df_silver.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed", "true")\
    .option("mergeSchema", "true")\
    .mode("overwrite")\
    .saveAsTable(f"{catalog}.{silver_schema}.{data_source}")
    

# COMMAND ----------

# MAGIC %md
# MAGIC ##Gold processing

# COMMAND ----------

# df_gold = spark.sql(f"select * from {catalog}.{silver_schema}.{data_source};")
df_gold = df_silver.select("customer_id","customer_name","city","customer","market","platform","channel")
df_gold.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed", "true")\
    .option("mergeSchema", "true")\
    .mode("overwrite")\
    .saveAsTable(f"{catalog}.{gold_schema}.sb_{data_source}")

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql import functions as F

# Target table
delta_table = DeltaTable.forName(
    spark,
    "fmcg.gold.dim_customers"
)

# Source DataFrame
df_child_customers = spark.table(
    "fmcg.gold.sb_customers"
).select(
    F.col("customer_id").alias("customer_code"),
    "customer",
    "market",
    "platform",
    "channel"
)

# Merge source into target
delta_table.alias("target").merge(
    df_child_customers.alias("source"),
    "target.customer_code = source.customer_code"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

# COMMAND ----------

result = delta_table.alias("target").merge(
    df_child_customers.alias("source"),
    "target.customer_code = source.customer_code"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

display(result)


# COMMAND ----------

df_final = spark.table("fmcg.gold.dim_customers")

display(df_final)

# COMMAND ----------

